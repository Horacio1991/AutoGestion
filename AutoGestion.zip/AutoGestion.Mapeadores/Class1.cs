﻿namespace AutoGestion.Mapeadores
{
    public class Class1
    {

    }
}
