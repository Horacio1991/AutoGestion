﻿namespace AutoGestion.Vista
{
    partial class AsignarRoles
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtIdUsuario = new TextBox();
            txtNombreUsuario = new TextBox();
            label3 = new Label();
            txtContrasenaUsuario = new TextBox();
            label4 = new Label();
            chkEncriptar = new CheckBox();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            txtNombreRol = new TextBox();
            txtIdRol = new TextBox();
            btnModificarRol = new Button();
            btnAltaRol = new Button();
            btnEliminarRol = new Button();
            label8 = new Label();
            label9 = new Label();
            cmbRoles = new ComboBox();
            txtIdRoles = new TextBox();
            txtNombresRoles = new TextBox();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            txtIdPermiso = new TextBox();
            txtNombrePermiso = new TextBox();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            cmbPermisoMenu = new ComboBox();
            cmbPermisoItem = new ComboBox();
            label17 = new Label();
            btnAltaPermiso = new Button();
            btnEliminarPermiso = new Button();
            btnLimpiarCampos = new Button();
            btnAsociarPermisoRol = new Button();
            btnQuitarPermisoRol = new Button();
            btnAsociarRolesUsuario = new Button();
            btnDesasociarRolesUsuario = new Button();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            btnAsociarRolUsuario = new Button();
            btnQuitarRolUsuario = new Button();
            btnAsociarPermisoUsuario = new Button();
            btnQuitarPermisoUsuario = new Button();
            label21 = new Label();
            label22 = new Label();
            label23 = new Label();
            label24 = new Label();
            label25 = new Label();
            tvUsuarios = new TreeView();
            tvRoles = new TreeView();
            tvPermisos = new TreeView();
            tvPermisosPorRol = new TreeView();
            tvRolesPermisosUsuario = new TreeView();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(0, 0);
            label1.Name = "label1";
            label1.Size = new Size(47, 15);
            label1.TabIndex = 0;
            label1.Text = "Usuario";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(9, 24);
            label2.Name = "label2";
            label2.Size = new Size(21, 15);
            label2.TabIndex = 1;
            label2.Text = "ID:";
            // 
            // txtIdUsuario
            // 
            txtIdUsuario.Location = new Point(85, 16);
            txtIdUsuario.Name = "txtIdUsuario";
            txtIdUsuario.Size = new Size(100, 23);
            txtIdUsuario.TabIndex = 2;
            // 
            // txtNombreUsuario
            // 
            txtNombreUsuario.Location = new Point(85, 50);
            txtNombreUsuario.Name = "txtNombreUsuario";
            txtNombreUsuario.Size = new Size(100, 23);
            txtNombreUsuario.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(9, 58);
            label3.Name = "label3";
            label3.Size = new Size(54, 15);
            label3.TabIndex = 3;
            label3.Text = "Nombre:";
            // 
            // txtContrasenaUsuario
            // 
            txtContrasenaUsuario.Location = new Point(85, 84);
            txtContrasenaUsuario.Name = "txtContrasenaUsuario";
            txtContrasenaUsuario.Size = new Size(100, 23);
            txtContrasenaUsuario.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(9, 92);
            label4.Name = "label4";
            label4.Size = new Size(70, 15);
            label4.TabIndex = 5;
            label4.Text = "Contraseña:";
            // 
            // chkEncriptar
            // 
            chkEncriptar.AutoSize = true;
            chkEncriptar.Location = new Point(191, 86);
            chkEncriptar.Name = "chkEncriptar";
            chkEncriptar.Size = new Size(133, 19);
            chkEncriptar.TabIndex = 7;
            chkEncriptar.Text = "Decifrar/Cifrar Clave";
            chkEncriptar.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(335, 0);
            label5.Name = "label5";
            label5.Size = new Size(24, 15);
            label5.TabIndex = 8;
            label5.Text = "Rol";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(338, 24);
            label6.Name = "label6";
            label6.Size = new Size(21, 15);
            label6.TabIndex = 9;
            label6.Text = "ID:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(407, 24);
            label7.Name = "label7";
            label7.Size = new Size(54, 15);
            label7.TabIndex = 10;
            label7.Text = "Nombre:";
            // 
            // txtNombreRol
            // 
            txtNombreRol.Location = new Point(467, 16);
            txtNombreRol.Name = "txtNombreRol";
            txtNombreRol.Size = new Size(113, 23);
            txtNombreRol.TabIndex = 11;
            // 
            // txtIdRol
            // 
            txtIdRol.Location = new Point(365, 16);
            txtIdRol.Name = "txtIdRol";
            txtIdRol.Size = new Size(36, 23);
            txtIdRol.TabIndex = 12;
            // 
            // btnModificarRol
            // 
            btnModificarRol.Location = new Point(424, 45);
            btnModificarRol.Name = "btnModificarRol";
            btnModificarRol.Size = new Size(75, 36);
            btnModificarRol.TabIndex = 13;
            btnModificarRol.Text = "Modificar";
            btnModificarRol.UseVisualStyleBackColor = true;
            // 
            // btnAltaRol
            // 
            btnAltaRol.Location = new Point(339, 45);
            btnAltaRol.Name = "btnAltaRol";
            btnAltaRol.Size = new Size(75, 36);
            btnAltaRol.TabIndex = 14;
            btnAltaRol.Text = "Alta";
            btnAltaRol.UseVisualStyleBackColor = true;
            btnAltaRol.Click += btnAltaRol_Click_1;
            // 
            // btnEliminarRol
            // 
            btnEliminarRol.Location = new Point(505, 45);
            btnEliminarRol.Name = "btnEliminarRol";
            btnEliminarRol.Size = new Size(75, 36);
            btnEliminarRol.TabIndex = 15;
            btnEliminarRol.Text = "Eliminar";
            btnEliminarRol.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(335, 91);
            label8.Name = "label8";
            label8.Size = new Size(210, 15);
            label8.TabIndex = 16;
            label8.Text = "Rol para Asociar/Desasociar a otro Rol:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(339, 115);
            label9.Name = "label9";
            label9.Size = new Size(38, 15);
            label9.TabIndex = 17;
            label9.Text = "Roles:";
            // 
            // cmbRoles
            // 
            cmbRoles.FormattingEnabled = true;
            cmbRoles.Location = new Point(383, 107);
            cmbRoles.Name = "cmbRoles";
            cmbRoles.Size = new Size(197, 23);
            cmbRoles.TabIndex = 18;
            // 
            // txtIdRoles
            // 
            txtIdRoles.Location = new Point(365, 140);
            txtIdRoles.Name = "txtIdRoles";
            txtIdRoles.Size = new Size(36, 23);
            txtIdRoles.TabIndex = 22;
            // 
            // txtNombresRoles
            // 
            txtNombresRoles.Location = new Point(467, 140);
            txtNombresRoles.Name = "txtNombresRoles";
            txtNombresRoles.Size = new Size(113, 23);
            txtNombresRoles.TabIndex = 21;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(407, 148);
            label10.Name = "label10";
            label10.Size = new Size(54, 15);
            label10.TabIndex = 20;
            label10.Text = "Nombre:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(338, 148);
            label11.Name = "label11";
            label11.Size = new Size(21, 15);
            label11.TabIndex = 19;
            label11.Text = "ID:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(617, 0);
            label12.Name = "label12";
            label12.Size = new Size(50, 15);
            label12.TabIndex = 23;
            label12.Text = "Permiso";
            // 
            // txtIdPermiso
            // 
            txtIdPermiso.Location = new Point(652, 18);
            txtIdPermiso.Name = "txtIdPermiso";
            txtIdPermiso.Size = new Size(36, 23);
            txtIdPermiso.TabIndex = 27;
            // 
            // txtNombrePermiso
            // 
            txtNombrePermiso.Location = new Point(754, 18);
            txtNombrePermiso.Name = "txtNombrePermiso";
            txtNombrePermiso.Size = new Size(113, 23);
            txtNombrePermiso.TabIndex = 26;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(694, 26);
            label13.Name = "label13";
            label13.Size = new Size(54, 15);
            label13.TabIndex = 25;
            label13.Text = "Nombre:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(625, 26);
            label14.Name = "label14";
            label14.Size = new Size(21, 15);
            label14.TabIndex = 24;
            label14.Text = "ID:";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(810, 66);
            label15.Name = "label15";
            label15.Size = new Size(34, 15);
            label15.TabIndex = 29;
            label15.Text = "Item:";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(625, 66);
            label16.Name = "label16";
            label16.Size = new Size(41, 15);
            label16.TabIndex = 28;
            label16.Text = "Menu:";
            // 
            // cmbPermisoMenu
            // 
            cmbPermisoMenu.FormattingEnabled = true;
            cmbPermisoMenu.Location = new Point(672, 58);
            cmbPermisoMenu.Name = "cmbPermisoMenu";
            cmbPermisoMenu.Size = new Size(121, 23);
            cmbPermisoMenu.TabIndex = 30;
            // 
            // cmbPermisoItem
            // 
            cmbPermisoItem.FormattingEnabled = true;
            cmbPermisoItem.Location = new Point(850, 58);
            cmbPermisoItem.Name = "cmbPermisoItem";
            cmbPermisoItem.Size = new Size(121, 23);
            cmbPermisoItem.TabIndex = 31;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(617, 148);
            label17.Name = "label17";
            label17.Size = new Size(141, 15);
            label17.TabIndex = 32;
            label17.Text = "Opciones Roles/Permisos";
            // 
            // btnAltaPermiso
            // 
            btnAltaPermiso.Location = new Point(694, 94);
            btnAltaPermiso.Name = "btnAltaPermiso";
            btnAltaPermiso.Size = new Size(99, 36);
            btnAltaPermiso.TabIndex = 34;
            btnAltaPermiso.Text = "Alta Permiso";
            btnAltaPermiso.UseVisualStyleBackColor = true;
            btnAltaPermiso.Click += btnAltaPermiso_Click;
            // 
            // btnEliminarPermiso
            // 
            btnEliminarPermiso.Location = new Point(810, 94);
            btnEliminarPermiso.Name = "btnEliminarPermiso";
            btnEliminarPermiso.Size = new Size(121, 36);
            btnEliminarPermiso.TabIndex = 33;
            btnEliminarPermiso.Text = "Eliminar Permiso";
            btnEliminarPermiso.UseVisualStyleBackColor = true;
            // 
            // btnLimpiarCampos
            // 
            btnLimpiarCampos.Location = new Point(810, 166);
            btnLimpiarCampos.Name = "btnLimpiarCampos";
            btnLimpiarCampos.Size = new Size(75, 60);
            btnLimpiarCampos.TabIndex = 37;
            btnLimpiarCampos.Text = "Limpiar Campos";
            btnLimpiarCampos.UseVisualStyleBackColor = true;
            // 
            // btnAsociarPermisoRol
            // 
            btnAsociarPermisoRol.Location = new Point(621, 166);
            btnAsociarPermisoRol.Name = "btnAsociarPermisoRol";
            btnAsociarPermisoRol.Size = new Size(67, 60);
            btnAsociarPermisoRol.TabIndex = 36;
            btnAsociarPermisoRol.Text = "Asociar Permiso a Rol";
            btnAsociarPermisoRol.UseVisualStyleBackColor = true;
            // 
            // btnQuitarPermisoRol
            // 
            btnQuitarPermisoRol.Location = new Point(706, 166);
            btnQuitarPermisoRol.Name = "btnQuitarPermisoRol";
            btnQuitarPermisoRol.Size = new Size(75, 60);
            btnQuitarPermisoRol.TabIndex = 35;
            btnQuitarPermisoRol.Text = "Quitar Permiso a Rol";
            btnQuitarPermisoRol.UseVisualStyleBackColor = true;
            // 
            // btnAsociarRolesUsuario
            // 
            btnAsociarRolesUsuario.Location = new Point(339, 169);
            btnAsociarRolesUsuario.Name = "btnAsociarRolesUsuario";
            btnAsociarRolesUsuario.Size = new Size(110, 60);
            btnAsociarRolesUsuario.TabIndex = 39;
            btnAsociarRolesUsuario.Text = "Asociar Roles a Usuario";
            btnAsociarRolesUsuario.UseVisualStyleBackColor = true;
            // 
            // btnDesasociarRolesUsuario
            // 
            btnDesasociarRolesUsuario.Location = new Point(470, 166);
            btnDesasociarRolesUsuario.Name = "btnDesasociarRolesUsuario";
            btnDesasociarRolesUsuario.Size = new Size(110, 60);
            btnDesasociarRolesUsuario.TabIndex = 38;
            btnDesasociarRolesUsuario.Text = "Desasociar Roles a Usuario";
            btnDesasociarRolesUsuario.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(3, 148);
            label18.Name = "label18";
            label18.Size = new Size(134, 15);
            label18.TabIndex = 40;
            label18.Text = "Roles/Permisos Usuario:";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(17, 166);
            label19.Name = "label19";
            label19.Size = new Size(90, 15);
            label19.TabIndex = 41;
            label19.Text = "Roles a Usuario:";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(191, 166);
            label20.Name = "label20";
            label20.Size = new Size(110, 15);
            label20.TabIndex = 42;
            label20.Text = "Permisos a Usuario:";
            // 
            // btnAsociarRolUsuario
            // 
            btnAsociarRolUsuario.Location = new Point(10, 184);
            btnAsociarRolUsuario.Name = "btnAsociarRolUsuario";
            btnAsociarRolUsuario.Size = new Size(67, 60);
            btnAsociarRolUsuario.TabIndex = 44;
            btnAsociarRolUsuario.Text = "Asociar Rol a Usuario";
            btnAsociarRolUsuario.UseVisualStyleBackColor = true;
            // 
            // btnQuitarRolUsuario
            // 
            btnQuitarRolUsuario.Location = new Point(83, 184);
            btnQuitarRolUsuario.Name = "btnQuitarRolUsuario";
            btnQuitarRolUsuario.Size = new Size(75, 60);
            btnQuitarRolUsuario.TabIndex = 43;
            btnQuitarRolUsuario.Text = "Quitar Rol a Usuario";
            btnQuitarRolUsuario.UseVisualStyleBackColor = true;
            // 
            // btnAsociarPermisoUsuario
            // 
            btnAsociarPermisoUsuario.Location = new Point(176, 184);
            btnAsociarPermisoUsuario.Name = "btnAsociarPermisoUsuario";
            btnAsociarPermisoUsuario.Size = new Size(67, 60);
            btnAsociarPermisoUsuario.TabIndex = 46;
            btnAsociarPermisoUsuario.Text = "Asociar Permiso a Usuario";
            btnAsociarPermisoUsuario.UseVisualStyleBackColor = true;
            // 
            // btnQuitarPermisoUsuario
            // 
            btnQuitarPermisoUsuario.Location = new Point(249, 184);
            btnQuitarPermisoUsuario.Name = "btnQuitarPermisoUsuario";
            btnQuitarPermisoUsuario.Size = new Size(75, 60);
            btnQuitarPermisoUsuario.TabIndex = 45;
            btnQuitarPermisoUsuario.Text = "Quitar Permiso a Usuario";
            btnQuitarPermisoUsuario.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(9, 262);
            label21.Name = "label21";
            label21.Size = new Size(55, 15);
            label21.TabIndex = 47;
            label21.Text = "Usuarios:";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(175, 262);
            label22.Name = "label22";
            label22.Size = new Size(38, 15);
            label22.TabIndex = 48;
            label22.Text = "Roles:";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(346, 262);
            label23.Name = "label23";
            label23.Size = new Size(58, 15);
            label23.TabIndex = 49;
            label23.Text = "Permisos:";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(514, 262);
            label24.Name = "label24";
            label24.Size = new Size(99, 15);
            label24.TabIndex = 50;
            label24.Text = "Permisos Por Rol:";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(683, 262);
            label25.Name = "label25";
            label25.Size = new Size(160, 15);
            label25.TabIndex = 51;
            label25.Text = "Roles y Permisos del Usuario:";
            // 
            // tvUsuarios
            // 
            tvUsuarios.Location = new Point(10, 280);
            tvUsuarios.Name = "tvUsuarios";
            tvUsuarios.Size = new Size(121, 226);
            tvUsuarios.TabIndex = 52;
            // 
            // tvRoles
            // 
            tvRoles.Location = new Point(179, 280);
            tvRoles.Name = "tvRoles";
            tvRoles.Size = new Size(121, 226);
            tvRoles.TabIndex = 53;
            // 
            // tvPermisos
            // 
            tvPermisos.Location = new Point(346, 283);
            tvPermisos.Name = "tvPermisos";
            tvPermisos.Size = new Size(121, 226);
            tvPermisos.TabIndex = 54;
            // 
            // tvPermisosPorRol
            // 
            tvPermisosPorRol.Location = new Point(514, 283);
            tvPermisosPorRol.Name = "tvPermisosPorRol";
            tvPermisosPorRol.Size = new Size(121, 226);
            tvPermisosPorRol.TabIndex = 55;
            // 
            // tvRolesPermisosUsuario
            // 
            tvRolesPermisosUsuario.Location = new Point(683, 283);
            tvRolesPermisosUsuario.Name = "tvRolesPermisosUsuario";
            tvRolesPermisosUsuario.Size = new Size(121, 226);
            tvRolesPermisosUsuario.TabIndex = 56;
            // 
            // AsignarRoles
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(tvRolesPermisosUsuario);
            Controls.Add(tvPermisosPorRol);
            Controls.Add(tvPermisos);
            Controls.Add(tvRoles);
            Controls.Add(tvUsuarios);
            Controls.Add(label25);
            Controls.Add(label24);
            Controls.Add(label23);
            Controls.Add(label22);
            Controls.Add(label21);
            Controls.Add(btnAsociarPermisoUsuario);
            Controls.Add(btnQuitarPermisoUsuario);
            Controls.Add(btnAsociarRolUsuario);
            Controls.Add(btnQuitarRolUsuario);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(btnAsociarRolesUsuario);
            Controls.Add(btnDesasociarRolesUsuario);
            Controls.Add(btnLimpiarCampos);
            Controls.Add(btnAsociarPermisoRol);
            Controls.Add(btnQuitarPermisoRol);
            Controls.Add(btnAltaPermiso);
            Controls.Add(btnEliminarPermiso);
            Controls.Add(label17);
            Controls.Add(cmbPermisoItem);
            Controls.Add(cmbPermisoMenu);
            Controls.Add(label15);
            Controls.Add(label16);
            Controls.Add(txtIdPermiso);
            Controls.Add(txtNombrePermiso);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(label12);
            Controls.Add(txtIdRoles);
            Controls.Add(txtNombresRoles);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(cmbRoles);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(btnEliminarRol);
            Controls.Add(btnAltaRol);
            Controls.Add(btnModificarRol);
            Controls.Add(txtIdRol);
            Controls.Add(txtNombreRol);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(chkEncriptar);
            Controls.Add(txtContrasenaUsuario);
            Controls.Add(label4);
            Controls.Add(txtNombreUsuario);
            Controls.Add(label3);
            Controls.Add(txtIdUsuario);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AsignarRoles";
            Size = new Size(975, 509);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtIdUsuario;
        private TextBox txtNombreUsuario;
        private Label label3;
        private TextBox txtContrasenaUsuario;
        private Label label4;
        private CheckBox chkEncriptar;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox txtNombreRol;
        private TextBox txtIdRol;
        private Button btnModificarRol;
        private Button btnAltaRol;
        private Button btnEliminarRol;
        private Label label8;
        private Label label9;
        private ComboBox cmbRoles;
        private TextBox txtIdRoles;
        private TextBox txtNombresRoles;
        private Label label10;
        private Label label11;
        private Label label12;
        private TextBox txtIdPermiso;
        private TextBox txtNombrePermiso;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private ComboBox cmbPermisoMenu;
        private ComboBox cmbPermisoItem;
        private Label label17;
        private Button btnAltaPermiso;
        private Button btnEliminarPermiso;
        private Button btnLimpiarCampos;
        private Button btnAsociarPermisoRol;
        private Button btnQuitarPermisoRol;
        private Button btnAsociarRolesUsuario;
        private Button btnDesasociarRolesUsuario;
        private Label label18;
        private Label label19;
        private Label label20;
        private Button btnAsociarRolUsuario;
        private Button btnQuitarRolUsuario;
        private Button btnAsociarPermisoUsuario;
        private Button btnQuitarPermisoUsuario;
        private Label label21;
        private Label label22;
        private Label label23;
        private Label label24;
        private Label label25;
        private TreeView tvUsuarios;
        private TreeView tvRoles;
        private TreeView tvPermisos;
        private TreeView tvPermisosPorRol;
        private TreeView tvRolesPermisosUsuario;
    }
}
