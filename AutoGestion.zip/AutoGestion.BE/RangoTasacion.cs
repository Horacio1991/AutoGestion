﻿namespace AutoGestion.BE
{
    public class RangoTasacion
    {
        public decimal Min { get; set; }
        public decimal Max { get; set; }
    }
}
