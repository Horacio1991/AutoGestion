﻿namespace AutoGestion.Entidades.Seguridad
{
    public static class Sesion
    {
        public static Usuario UsuarioActual { get; set; }
    }
}
